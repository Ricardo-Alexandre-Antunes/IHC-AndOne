npm i react-router-dom
npm install react-bootstrap bootstrap
npm install bootstrap
npm i --save bootstrap @popperjs/core
npm i --save-dev sass
npm install --save @fortawesome/fontawesome-svg-core
npm install --save @fortawesome/free-solid-svg-icons
npm install --save @fortawesome/react-fontawesome
npm install react-bootstrap-range-slider
npm install rc-slider
npm install jspdf
npm install jspdf-autotable