# IHC-AndOne
Project for IHC class for Software Engineering @ Universidade de Aveiro (2023-2024 / 2nd year)

How to run:

after cloning execute 'npm install'

to run 'npm run dev'
